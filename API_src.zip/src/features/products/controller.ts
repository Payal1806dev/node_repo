import express from "express";
import productService from "./Services";
export const getProducts = async (request: express.Request, response: express.Response) => {
    try {
        const result = await productService.getAllProducts();
        console.log(result)
        response.status(201).json(result)
    } catch (error) {
        response.status(400).json(error)
    }
};


export const addProducts = async (request: express.Request, response: express.Response) =>{
    try{
        const {name, brand, price, category}= request.body;
        const productData = {name, brand, price, category};
        const result = await productService.addProducts(productData);
        response.status(201).json(result)
    }catch (error) {
        response.status(400).json(error)
    }
}

export const UpdateProduct = async (request: express.Request, response: express.Response) => {
try{
    
        const { name, brand, category, price } = request.body;
        const ProductData = { name, brand, category, price }
   
        const result = await productService.ProductUpdate(ProductData,name);
        response.status(200).json(result);

}

catch(error) {
    response.status(400).json(error)
}

}

