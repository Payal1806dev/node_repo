import { response } from "express";
import { productType } from "./interface";
import { ProductModel } from "./Model";
class productService {
  async getAllProducts() {
    try {
      const product = await ProductModel.find();
      console.log(product);
      return product;
    } catch (error) {
      return "Product not found";
    }
  }

  async addProducts(productData: productType) {
    try {
      const { name, brand, price, category } = productData;
      const product = new ProductModel({
        name,
        brand,
        price,
        category,
      });
      const res = await product.save();
      return res;
    } catch (error) {
      return "Product not added";
    }
  }


async ProductUpdate(productData: productType, name:string){
    try{
          const product=await ProductModel.findOneAndUpdate({ name}, productData, {new:true});
    }
    catch(error){
        return "Product not updated";
    }
    return response;
}




}












export default new productService();
