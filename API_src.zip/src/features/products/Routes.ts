import  express from "express"
import { UpdateProduct, addProducts, getProducts } from "./controller";

const ProductRouter=express.Router();
ProductRouter.get('/products', getProducts);
ProductRouter.post('/create-products', addProducts);
ProductRouter.put('/update-products', UpdateProduct);
export default ProductRouter;