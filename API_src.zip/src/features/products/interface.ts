export interface productType{
    name: string;
    brand: string;
    price: number;
    category: string;
}